(function () {
  'use strict';

  const STORAGE_KEY = 'ledger.tasks.v1';

  /** @type {{id:string, text:string, completed:boolean}[]} */
  let tasks = loadTasks();
  let currentFilter = 'all'; // 'all' | 'active' | 'completed'

  // ---- DOM refs ----
  const form = document.getElementById('task-form');
  const input = document.getElementById('task-input');
  const list = document.getElementById('task-list');
  const emptyState = document.getElementById('empty-state');
  const itemsLeft = document.getElementById('items-left');
  const clearCompletedBtn = document.getElementById('clear-completed');
  const filterBtns = document.querySelectorAll('.filter-btn');

  // ---- Persistence ----
  function loadTasks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      console.error('Failed to load tasks from localStorage:', err);
      return [];
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      console.error('Failed to save tasks to localStorage:', err);
    }
  }

  // ---- CRUD ----
  function createTask(text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    tasks.push({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()),
      text: trimmed,
      completed: false,
    });
    saveTasks();
    render();
  }

  function updateTaskText(id, newText) {
    const trimmed = newText.trim();
    const task = tasks.find((t) => t.id === id);
    if (!task) return;
    if (trimmed) {
      task.text = trimmed;
    }
    saveTasks();
    render();
  }

  function toggleTaskCompleted(id) {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;
    task.completed = !task.completed;
    saveTasks();
    render();
  }

  function deleteTask(id) {
    tasks = tasks.filter((t) => t.id !== id);
    saveTasks();
    render();
  }

  function clearCompleted() {
    tasks = tasks.filter((t) => !t.completed);
    saveTasks();
    render();
  }

  // ---- Filtering ----
  function getFilteredTasks() {
    if (currentFilter === 'active') return tasks.filter((t) => !t.completed);
    if (currentFilter === 'completed') return tasks.filter((t) => t.completed);
    return tasks;
  }

  function setFilter(filter) {
    currentFilter = filter;
    filterBtns.forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.filter === filter);
    });
    render();
  }

  // ---- Rendering (dynamic DOM creation) ----
  function render() {
    list.innerHTML = '';
    const visible = getFilteredTasks();

    visible.forEach((task) => {
      list.appendChild(buildTaskElement(task));
    });

    emptyState.hidden = tasks.length > 0;
    if (tasks.length > 0 && visible.length === 0) {
      emptyState.hidden = false;
      emptyState.textContent = `No ${currentFilter} tasks.`;
    } else if (tasks.length === 0) {
      emptyState.textContent = 'Nothing here yet — add your first task above.';
    }

    const remaining = tasks.filter((t) => !t.completed).length;
    itemsLeft.textContent = `${remaining} item${remaining === 1 ? '' : 's'} left`;

    const hasCompleted = tasks.some((t) => t.completed);
    clearCompletedBtn.disabled = !hasCompleted;
  }

  function buildTaskElement(task) {
    const li = document.createElement('li');
    li.className = 'task-item' + (task.completed ? ' is-completed' : '');
    li.dataset.id = task.id;

    const checkbox = document.createElement('button');
    checkbox.type = 'button';
    checkbox.className = 'task-checkbox' + (task.completed ? ' is-checked' : '');
    checkbox.setAttribute('aria-label', task.completed ? 'Mark as active' : 'Mark as completed');
    checkbox.dataset.action = 'toggle';

    const text = document.createElement('span');
    text.className = 'task-text';
    text.textContent = task.text;
    text.dataset.action = 'edit';

    const actions = document.createElement('div');
    actions.className = 'task-actions';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'task-btn edit';
    editBtn.textContent = 'Edit';
    editBtn.dataset.action = 'edit';

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'task-btn delete';
    deleteBtn.textContent = 'Delete';
    deleteBtn.dataset.action = 'delete';

    actions.appendChild(editBtn);
    actions.appendChild(deleteBtn);

    li.appendChild(checkbox);
    li.appendChild(text);
    li.appendChild(actions);

    return li;
  }

  function startEditing(li, task) {
    const textEl = li.querySelector('.task-text');
    const inputEl = document.createElement('input');
    inputEl.type = 'text';
    inputEl.className = 'task-edit-input';
    inputEl.value = task.text;
    inputEl.maxLength = 140;
    li.replaceChild(inputEl, textEl);
    inputEl.focus();
    inputEl.setSelectionRange(inputEl.value.length, inputEl.value.length);

    let committed = false;
    function commit() {
      if (committed) return;
      committed = true;
      updateTaskText(task.id, inputEl.value);
    }

    inputEl.addEventListener('blur', commit);
    inputEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        commit();
      } else if (e.key === 'Escape') {
        committed = true;
        render();
      }
    });
  }

  // ---- Event delegation ----
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    createTask(input.value);
    input.value = '';
    input.focus();
  });

  // Single delegated listener handles toggle / edit / delete for every task,
  // including tasks created after page load.
  list.addEventListener('click', (e) => {
    const actionEl = e.target.closest('[data-action]');
    if (!actionEl) return;
    const li = e.target.closest('.task-item');
    if (!li) return;
    const id = li.dataset.id;
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    const action = actionEl.dataset.action;
    if (action === 'toggle') {
      toggleTaskCompleted(id);
    } else if (action === 'edit') {
      startEditing(li, task);
    } else if (action === 'delete') {
      li.style.opacity = '0';
      setTimeout(() => deleteTask(id), 120);
    }
  });

  clearCompletedBtn.addEventListener('click', clearCompleted);

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => setFilter(btn.dataset.filter));
  });

  // ---- Initial render ----
  render();
})();
