// Mobile nav toggle — keeps aria-expanded in sync for screen readers
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');

  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // Accessible contact form validation (only present on contact.html)
  var form = document.getElementById('contact-form');
  if (!form) return;

  var status = document.getElementById('form-status');

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var valid = true;
    var fields = form.querySelectorAll('[required]');

    fields.forEach(function (field) {
      var wrapper = field.closest('.form-field');
      var errorEl = wrapper.querySelector('.error-msg');
      var fieldValid = field.checkValidity();

      wrapper.setAttribute('data-invalid', fieldValid ? 'false' : 'true');
      if (errorEl) errorEl.id = errorEl.id || (field.id + '-error');
      if (!fieldValid) {
        valid = false;
        field.setAttribute('aria-invalid', 'true');
        if (errorEl) field.setAttribute('aria-describedby', errorEl.id);
      } else {
        field.setAttribute('aria-invalid', 'false');
      }
    });

    status.classList.remove('success');
    status.classList.add('visible');

    if (valid) {
      status.classList.add('success');
      status.textContent = 'Thanks — your message has been noted. (This demo form does not actually send email yet.)';
      status.setAttribute('role', 'status');
      form.reset();
      fields.forEach(function (f) {
        f.closest('.form-field').setAttribute('data-invalid', 'false');
      });
    } else {
      status.textContent = 'Please fix the highlighted fields before submitting.';
      status.setAttribute('role', 'alert');
      var firstInvalid = form.querySelector('[aria-invalid="true"]');
      if (firstInvalid) firstInvalid.focus();
    }
  });
});
