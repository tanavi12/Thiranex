# Semantic & Accessible Portfolio — Starter Kit

A 4-page personal portfolio skeleton built to the assignment brief:
semantic HTML5 landmarks, ARIA labels/roles, SEO meta tags, and an
accessible, tab-navigable contact form.

## Files

```
portfolio-starter/
├── index.html       Home page
├── about.html        About / skills / experience
├── portfolio.html    Projects grid
├── contact.html       Accessible contact form
├── css/style.css      All styling + design tokens
├── js/main.js          Mobile nav toggle + form validation
└── README.md
```

## How to view it

No build step needed — just open `index.html` in a browser, or run a
local server from this folder (recommended, so relative paths behave
exactly like a real deploy):

```
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## What's already covered

- **Semantic tags**: `<header>`, `<nav>`, `<main>`, `<section>`,
  `<article>`, `<aside>`, `<footer>` on every page — one `<main>` per
  page, one `<h1>` per page, logical heading order.
- **ARIA**: `aria-label` on the nav and icon-only menu button,
  `aria-current="page"` on the active nav link, `aria-expanded` on the
  mobile toggle, `aria-required` / `aria-invalid` / `aria-describedby`
  on form fields, `role="status"`/`role="alert"` on form feedback.
- **SEO meta tags**: unique `<title>`, `meta description`, canonical
  link, and Open Graph / Twitter tags on every page.
- **Accessible contact form**: every input has a linked `<label>`,
  natural DOM tab order (no manual `tabindex`), visible focus states,
  and JS validation that announces errors to screen readers instead of
  relying on browser tooltips alone.
- **Skip link** at the top of every page so keyboard users can bypass
  the nav.
- A small `.landmark-tag` label sits at the top of each region in the
  markup, showing which semantic tag wraps it — a built-in visual
  answer key while you're learning the structure. Delete these spans
  once you're comfortable, or leave them as documentation.

## What you should customize

1. **Content**: swap the placeholder name, bio, skills, project
   cards, and images for your own.
2. **Meta tags**: update every `<title>`, `meta description`, and
   `og:url` / `canonical` link to your real domain once you deploy.
3. **Images**: replace the `placehold.co` placeholders in
   `portfolio.html` with real screenshots, and keep writing specific
   `alt` text (describe what's *in* the image, not just "screenshot").
4. **Form backend**: the JS only validates and shows a success
   message — it doesn't send email. Wire it to a form service (e.g.
   Formspree, Netlify Forms) or your own backend endpoint when ready.
5. **Colors/fonts**: all design tokens are CSS variables at the top of
   `style.css` (`:root { ... }`) if you want to restyle without
   touching the rest of the file.

## Testing for the "100 on Lighthouse" goal

1. Open the page in Chrome → DevTools → **Lighthouse** tab → run
   Accessibility + SEO audits.
2. Tab through the entire page using only your keyboard — check that
   focus is always visible and the order makes sense.
3. Turn on VoiceOver (Mac: Cmd+F5) or NVDA (Windows, free) and listen
   to how the page reads.
4. Run an HTML validator (https://validator.w3.org/) to catch any
   unclosed tags or invalid nesting before you submit.
