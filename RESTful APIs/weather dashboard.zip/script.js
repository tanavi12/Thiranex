(function () {
  'use strict';

  // Open-Meteo: free, keyless, public REST APIs.
  const GEOCODE_URL = 'https://geocoding-api.open-meteo.com/v1/search';
  const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';

  // WMO weather codes -> icon + label. Open-Meteo returns these as integers.
  const WEATHER_CODES = {
    0: { icon: '☀️', text: 'Clear sky' },
    1: { icon: '🌤️', text: 'Mainly clear' },
    2: { icon: '⛅', text: 'Partly cloudy' },
    3: { icon: '☁️', text: 'Overcast' },
    45: { icon: '🌫️', text: 'Fog' },
    48: { icon: '🌫️', text: 'Depositing rime fog' },
    51: { icon: '🌦️', text: 'Light drizzle' },
    53: { icon: '🌦️', text: 'Moderate drizzle' },
    55: { icon: '🌦️', text: 'Dense drizzle' },
    61: { icon: '🌧️', text: 'Slight rain' },
    63: { icon: '🌧️', text: 'Moderate rain' },
    65: { icon: '🌧️', text: 'Heavy rain' },
    66: { icon: '🌧️', text: 'Freezing rain' },
    67: { icon: '🌧️', text: 'Freezing rain' },
    71: { icon: '🌨️', text: 'Slight snow' },
    73: { icon: '🌨️', text: 'Moderate snow' },
    75: { icon: '🌨️', text: 'Heavy snow' },
    77: { icon: '🌨️', text: 'Snow grains' },
    80: { icon: '🌦️', text: 'Rain showers' },
    81: { icon: '🌦️', text: 'Rain showers' },
    82: { icon: '⛈️', text: 'Violent rain showers' },
    85: { icon: '🌨️', text: 'Snow showers' },
    86: { icon: '🌨️', text: 'Snow showers' },
    95: { icon: '⛈️', text: 'Thunderstorm' },
    96: { icon: '⛈️', text: 'Thunderstorm with hail' },
    99: { icon: '⛈️', text: 'Thunderstorm with hail' },
  };

  const WIND_COMPASS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];

  // ---- DOM refs ----
  const form = document.getElementById('search-form');
  const cityInput = document.getElementById('city-input');
  const searchBtn = form.querySelector('.btn-search');
  const statusEl = document.getElementById('status');
  const card = document.getElementById('weather-card');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = cityInput.value.trim();
    if (query) loadWeatherForCity(query);
  });

  /**
   * Orchestrates geocoding + forecast fetches for a given city name.
   * Wraps both network calls in try/catch/finally so any failure
   * (bad city name, offline, malformed response) surfaces as a
   * readable error instead of a silent break.
   */
  async function loadWeatherForCity(query) {
    setLoading(true, `Looking up "${query}"…`);
    card.hidden = true;
    searchBtn.disabled = true;

    try {
      const place = await geocodeCity(query);
      setLoading(true, `Fetching current conditions for ${place.name}…`);
      const weather = await fetchForecast(place.latitude, place.longitude);
      renderWeather(place, weather);
      clearStatus();
    } catch (err) {
      showError(err.message || 'Something went wrong. Please try again.');
    } finally {
      searchBtn.disabled = false;
    }
  }

  /**
   * Resolves a free-text city name to coordinates via Open-Meteo's
   * geocoding API. Throws a descriptive error on network failure,
   * bad HTTP status, or an empty result set (city not found).
   */
  async function geocodeCity(query) {
    const url = `${GEOCODE_URL}?name=${encodeURIComponent(query)}&count=1&language=en&format=json`;
    let response;
    try {
      response = await fetch(url);
    } catch (networkErr) {
      throw new Error('Network error while searching for that city. Check your connection and try again.');
    }

    if (!response.ok) {
      throw new Error(`City lookup failed (HTTP ${response.status}). Please try again.`);
    }

    const data = await response.json();
    if (!data.results || data.results.length === 0) {
      throw new Error(`No results for "${query}". Check the spelling or try a nearby larger city.`);
    }

    const match = data.results[0];
    return {
      name: match.name,
      country: match.country,
      admin1: match.admin1,
      latitude: match.latitude,
      longitude: match.longitude,
      timezone: match.timezone,
    };
  }

  /**
   * Fetches current conditions and a 5-day daily forecast for the
   * given coordinates. Mirrors the same fetch/try/catch pattern as
   * geocodeCity so both API calls fail gracefully and independently.
   */
  async function fetchForecast(latitude, longitude) {
    const params = new URLSearchParams({
      latitude,
      longitude,
      current: 'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,surface_pressure',
      daily: 'weather_code,temperature_2m_max,temperature_2m_min',
      forecast_days: '5',
      timezone: 'auto',
    });

    let response;
    try {
      response = await fetch(`${FORECAST_URL}?${params.toString()}`);
    } catch (networkErr) {
      throw new Error('Network error while fetching weather data. Check your connection and try again.');
    }

    if (!response.ok) {
      throw new Error(`Weather service returned an error (HTTP ${response.status}).`);
    }

    const data = await response.json();
    if (!data.current || !data.daily) {
      throw new Error('Unexpected response shape from the weather service.');
    }
    return data;
  }

  // ---- Rendering: parses nested JSON and builds DOM dynamically ----
  function renderWeather(place, data) {
    const current = data.current;
    const daily = data.daily;

    document.getElementById('city-name').textContent =
      [place.name, place.admin1, place.country].filter(Boolean).join(', ');
    document.getElementById('observed-at').textContent =
      `Observed ${formatTime(current.time)}`;

    const condition = WEATHER_CODES[current.weather_code] || { icon: '❓', text: 'Unknown' };
    document.getElementById('condition-icon').textContent = condition.icon;
    document.getElementById('condition-text').textContent = condition.text;

    document.getElementById('temperature').textContent = Math.round(current.temperature_2m);
    document.getElementById('feels-like').textContent =
      `Feels like ${Math.round(current.apparent_temperature)}°C`;

    document.getElementById('metric-humidity').textContent = `${current.relative_humidity_2m}%`;
    document.getElementById('metric-wind').textContent = `${Math.round(current.wind_speed_10m)} km/h`;
    document.getElementById('metric-wind-dir').textContent = degreesToCompass(current.wind_direction_10m);
    document.getElementById('metric-pressure').textContent = `${Math.round(current.surface_pressure)} hPa`;

    renderForecast(daily);

    card.hidden = false;
  }

  function renderForecast(daily) {
    const list = document.getElementById('forecast-list');
    list.innerHTML = '';

    daily.time.forEach((dateStr, i) => {
      const code = daily.weather_code[i];
      const condition = WEATHER_CODES[code] || { icon: '❓', text: 'Unknown' };
      const max = Math.round(daily.temperature_2m_max[i]);
      const min = Math.round(daily.temperature_2m_min[i]);

      const li = document.createElement('li');
      li.className = 'forecast-day';

      const label = document.createElement('span');
      label.className = 'day-label';
      label.textContent = formatWeekday(dateStr, i);

      const icon = document.createElement('span');
      icon.className = 'day-icon';
      icon.textContent = condition.icon;
      icon.title = condition.text;

      const temps = document.createElement('span');
      temps.className = 'day-temps';
      temps.innerHTML = `${max}° <span class="low">${min}°</span>`;

      li.appendChild(label);
      li.appendChild(icon);
      li.appendChild(temps);
      list.appendChild(li);
    });
  }

  // ---- Status / error UI ----
  function setLoading(isLoading, message) {
    if (!isLoading) return;
    statusEl.hidden = false;
    statusEl.className = 'status is-loading';
    statusEl.textContent = message;
  }

  function showError(message) {
    statusEl.hidden = false;
    statusEl.className = 'status is-error';
    statusEl.textContent = message;
    card.hidden = true;
  }

  function clearStatus() {
    statusEl.hidden = true;
    statusEl.textContent = '';
  }

  // ---- Formatting helpers ----
  function degreesToCompass(deg) {
    const index = Math.round(deg / 22.5) % 16;
    return `${WIND_COMPASS[index]} (${Math.round(deg)}°)`;
  }

  function formatTime(isoString) {
    const d = new Date(isoString);
    return d.toLocaleString(undefined, { weekday: 'short', hour: '2-digit', minute: '2-digit' });
  }

  function formatWeekday(dateStr, index) {
    if (index === 0) return 'Today';
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString(undefined, { weekday: 'short' });
  }

  // Load a default city on first paint so the dashboard isn't empty.
  loadWeatherForCity('Bengaluru');
})();
