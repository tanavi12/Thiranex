(function () {
  const root = document.documentElement;
  const toggle = document.getElementById('theme-toggle');
  const stateLabel = document.getElementById('theme-state');

  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  let theme = prefersDark ? 'dark' : 'light';
  applyTheme(theme);

  toggle.addEventListener('click', function () {
    theme = theme === 'light' ? 'dark' : 'light';
    applyTheme(theme);
  });

  function applyTheme(mode) {
    if (mode === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
    stateLabel.textContent = mode.toUpperCase();
    toggle.setAttribute('aria-pressed', String(mode === 'dark'));
  }
})();
