// Production build: bundles + minifies JS (ESM, tree-shaken), minifies
// CSS, and minifies HTML. This is the "optimize assets" step from the
// brief — dist/ is what actually gets deployed, not src/.

const esbuild = require('esbuild');
const { minify } = require('html-minifier-terser');
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, 'src');
const DIST = path.join(__dirname, 'dist');

async function build() {
  fs.rmSync(DIST, { recursive: true, force: true });
  fs.mkdirSync(path.join(DIST, 'js'), { recursive: true });
  fs.mkdirSync(path.join(DIST, 'css'), { recursive: true });

  // --- JS: bundle all ES modules into one minified file ---
  const jsResult = await esbuild.build({
    entryPoints: [path.join(SRC, 'js/main.js')],
    bundle: true,
    minify: true,
    format: 'esm',
    target: 'es2020',
    outfile: path.join(DIST, 'js/bundle.min.js'),
    metafile: true,
  });

  // --- CSS: minify ---
  const cssResult = await esbuild.build({
    entryPoints: [path.join(SRC, 'css/styles.css')],
    minify: true,
    outfile: path.join(DIST, 'css/styles.min.css'),
  });

  // --- HTML: point at bundled/minified assets, then minify ---
  let html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
  html = html
    .replace('css/styles.css', 'css/styles.min.css')
    .replace(
      '<script type="module" src="js/main.js"></script>',
      '<script type="module" src="js/bundle.min.js"></script>'
    );

  const minifiedHtml = await minify(html, {
    collapseWhitespace: true,
    removeComments: true,
    minifyCSS: true,
    minifyJS: true,
  });
  fs.writeFileSync(path.join(DIST, 'index.html'), minifiedHtml);

  // --- Deployment configs ---
  copyIfExists('vercel.json');
  copyIfExists('netlify.toml');

  // --- Report sizes ---
  report();
}

function copyIfExists(file) {
  const from = path.join(__dirname, file);
  if (fs.existsSync(from)) {
    fs.copyFileSync(from, path.join(DIST, file));
  }
}

function report() {
  const files = [
    ['src/js (source, all modules)', dirSize(path.join(SRC, 'js'))],
    ['dist/js/bundle.min.js', fileSize(path.join(DIST, 'js/bundle.min.js'))],
    ['src/css/styles.css', fileSize(path.join(SRC, 'css/styles.css'))],
    ['dist/css/styles.min.css', fileSize(path.join(DIST, 'css/styles.min.css'))],
    ['src/index.html', fileSize(path.join(SRC, 'index.html'))],
    ['dist/index.html', fileSize(path.join(DIST, 'index.html'))],
  ];
  console.log('\nBuild output — size comparison:');
  files.forEach(([label, bytes]) => {
    console.log(`  ${label.padEnd(32)} ${bytes} bytes`);
  });
}

function fileSize(p) {
  return fs.existsSync(p) ? fs.statSync(p).size : 0;
}

function dirSize(dir) {
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    total += entry.isDirectory() ? dirSize(p) : fs.statSync(p).size;
  }
  return total;
}

build().catch((err) => {
  console.error(err);
  process.exit(1);
});
