import { initRouter, registerRoute, registerNotFound } from './router.js';
import { renderCatalog } from './views/catalog.js';
import { renderProduct } from './views/product.js';
import { renderCart } from './views/cart.js';
import { renderCheckout, renderNotFound } from './views/misc.js';
import { addToCart, updateQty, removeFromCart, clearCart, subscribe, getCartDetails } from './store.js';

const outlet = document.getElementById('view-outlet');
const cartCountEl = document.getElementById('cart-count');

// ---- Routes ----
registerRoute('/', renderCatalog);
registerRoute('/category/:category', renderCatalog);
registerRoute('/product/:id', renderProduct);
registerRoute('/cart', renderCart);
registerRoute('/checkout', renderCheckout);
registerNotFound(renderNotFound);

initRouter(outlet);

// ---- Cart badge stays in sync with store, independent of routing ----
function updateCartBadge() {
  const { count } = getCartDetails();
  cartCountEl.textContent = count;
  cartCountEl.hidden = count === 0;
}
subscribe(updateCartBadge);
updateCartBadge();

// ---- Delegated event handling: one listener covers every route ----
// Views are re-rendered wholesale on navigation, so per-element
// listeners would leak or go stale. Delegating to a stable ancestor
// (document.body) means new markup "just works" with no rebinding.
document.body.addEventListener('click', (e) => {
  const addBtn = e.target.closest('[data-add]');
  if (addBtn) {
    const productId = addBtn.dataset.add;
    const qtySourceId = addBtn.dataset.qtySource;
    const qty = qtySourceId
      ? Math.max(1, parseInt(document.getElementById(qtySourceId).value, 10) || 1)
      : 1;
    addToCart(productId, qty);
    flashButton(addBtn);
    return;
  }

  const qtyBtn = e.target.closest('[data-qty-action]');
  if (qtyBtn) {
    const id = qtyBtn.dataset.id;
    const lineEl = qtyBtn.closest('.cart-line');
    const currentQty = parseInt(lineEl.querySelector('.qty-value').textContent, 10);
    const nextQty = qtyBtn.dataset.qtyAction === 'increment' ? currentQty + 1 : currentQty - 1;
    updateQty(id, nextQty);
    rerenderCurrentRoute();
    return;
  }

  const removeBtn = e.target.closest('[data-remove]');
  if (removeBtn) {
    removeFromCart(removeBtn.dataset.remove);
    rerenderCurrentRoute();
    return;
  }

  if (e.target.id === 'clear-cart') {
    clearCart();
    rerenderCurrentRoute();
    return;
  }

  if (e.target.id === 'checkout') {
    clearCart();
    window.location.hash = '/checkout';
  }
});

function flashButton(btn) {
  const original = btn.textContent;
  btn.textContent = 'Added ✓';
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
  }, 900);
}

function rerenderCurrentRoute() {
  // Cheapest correct way to reflect cart mutations in the current
  // view without a virtual-DOM diffing layer: re-fire the router.
  window.dispatchEvent(new Event('hashchange'));
}
