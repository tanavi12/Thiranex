// Static product catalog. In a real deployment this would come from
// a CMS or backend API — kept as a module here so it's a single,
// swappable seam (see README "Connecting a real backend").

export const products = [
  {
    id: 'p1',
    name: 'Aalto Ceramic Pour-Over',
    category: 'Kitchen',
    price: 42.0,
    color: '#2F5CFF',
    description:
      'Hand-glazed ceramic dripper with a slow, even extraction cone. Fits any mug 3in or wider.',
  },
  {
    id: 'p2',
    name: 'Fieldnote Leather Journal',
    category: 'Stationery',
    price: 28.5,
    color: '#E2793B',
    description:
      'Vegetable-tanned cover, 160 pages of 100gsm dot-grid paper, lies flat at any spread.',
  },
  {
    id: 'p3',
    name: 'Orbit Desk Lamp',
    category: 'Lighting',
    price: 89.0,
    color: '#1FA971',
    description:
      'Adjustable arm, warm-to-cool dimmable LED, USB-C passthrough charging in the base.',
  },
  {
    id: 'p4',
    name: 'Basalt Wool Throw',
    category: 'Home',
    price: 64.0,
    color: '#5B6269',
    description:
      'Mid-weight merino wool blend, woven in a small mill, machine washable on cold.',
  },
  {
    id: 'p5',
    name: 'Meridian Mechanical Keyboard',
    category: 'Tech',
    price: 145.0,
    color: '#B03A5B',
    description:
      'Hot-swappable switches, aluminum top plate, wireless or USB-C wired, 4000mAh battery.',
  },
  {
    id: 'p6',
    name: 'Loam Terracotta Planter',
    category: 'Home',
    price: 19.0,
    color: '#C97A3D',
    description:
      'Unglazed terracotta, drainage saucer included, 6in diameter — fits most starter plants.',
  },
  {
    id: 'p7',
    name: 'Transit Canvas Tote',
    category: 'Bags',
    price: 34.0,
    color: '#2B6CB0',
    description:
      '16oz waxed canvas, leather base reinforcement, holds a 15in laptop plus daily carry.',
  },
  {
    id: 'p8',
    name: 'Halcyon Sound Machine',
    category: 'Tech',
    price: 55.0,
    color: '#6E4FA1',
    description:
      'Analog-modeled white noise generator, no app or wifi required, battery or USB-C powered.',
  },
];

export function getProductById(id) {
  return products.find((p) => p.id === id) || null;
}

export function getCategories() {
  return [...new Set(products.map((p) => p.category))].sort();
}
