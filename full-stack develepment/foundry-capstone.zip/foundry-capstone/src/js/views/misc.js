export function renderCheckout() {
  return `
    <section class="checkout-page">
      <div class="confirm-badge" aria-hidden="true">✓</div>
      <h1>Order placed</h1>
      <p>This is a demo checkout — no payment was processed and no data left your browser.</p>
      <a class="btn-primary" href="#/">Continue shopping</a>
    </section>
  `;
}

export function renderNotFound() {
  return `
    <section class="not-found">
      <h1>Page not found</h1>
      <p>That route doesn't exist.</p>
      <a class="btn-primary" href="#/">Back to shop</a>
    </section>
  `;
}
