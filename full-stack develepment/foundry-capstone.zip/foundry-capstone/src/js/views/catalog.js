import { products, getCategories } from '../data/products.js';

function productCard(p) {
  return `
    <li class="product-card">
      <a href="#/product/${p.id}" class="product-link">
        <div class="product-thumb" style="background:${p.color}22" role="img" aria-label="${p.name}">
          <span class="thumb-mark" style="background:${p.color}"></span>
        </div>
        <div class="product-info">
          <p class="product-category">${p.category}</p>
          <h3 class="product-name">${p.name}</h3>
          <p class="product-price">$${p.price.toFixed(2)}</p>
        </div>
      </a>
      <button class="btn-quick-add" type="button" data-add="${p.id}">Add to cart</button>
    </li>
  `;
}

export function renderCatalog(params) {
  const activeCategory = params.category || 'all';
  const categories = getCategories();
  const visible =
    activeCategory === 'all' ? products : products.filter((p) => p.category === activeCategory);

  const filterChips = ['all', ...categories]
    .map(
      (c) => `
        <a
          class="chip ${c === activeCategory ? 'is-active' : ''}"
          href="#/category/${encodeURIComponent(c)}"
        >${c === 'all' ? 'All' : c}</a>
      `
    )
    .join('');

  return `
    <section class="catalog">
      <div class="catalog-header">
        <h1>Shop the collection</h1>
        <p class="catalog-sub">${visible.length} item${visible.length === 1 ? '' : 's'}</p>
      </div>
      <div class="chip-row" id="category-chips">${filterChips}</div>
      <ul class="product-grid">
        ${visible.map(productCard).join('')}
      </ul>
    </section>
  `;
}
