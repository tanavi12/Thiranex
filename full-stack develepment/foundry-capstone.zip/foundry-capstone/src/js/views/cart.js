import { getCartDetails } from '../store.js';

function cartLine(line) {
  return `
    <li class="cart-line" data-line-id="${line.productId}">
      <div class="cart-line-thumb" style="background:${line.product.color}22">
        <span class="thumb-mark" style="background:${line.product.color}"></span>
      </div>
      <div class="cart-line-info">
        <a href="#/product/${line.productId}" class="cart-line-name">${line.product.name}</a>
        <p class="cart-line-price">$${line.product.price.toFixed(2)} each</p>
      </div>
      <div class="cart-line-qty">
        <button type="button" class="qty-btn" data-qty-action="decrement" data-id="${line.productId}" aria-label="Decrease quantity">−</button>
        <span class="qty-value">${line.qty}</span>
        <button type="button" class="qty-btn" data-qty-action="increment" data-id="${line.productId}" aria-label="Increase quantity">+</button>
      </div>
      <p class="cart-line-subtotal">$${line.subtotal.toFixed(2)}</p>
      <button type="button" class="cart-line-remove" data-remove="${line.productId}" aria-label="Remove ${line.product.name}">Remove</button>
    </li>
  `;
}

export function renderCart() {
  const { lines, total } = getCartDetails();

  if (lines.length === 0) {
    return `
      <section class="cart-page">
        <h1>Your cart</h1>
        <p class="cart-empty">Your cart is empty. <a href="#/">Browse the shop</a>.</p>
      </section>
    `;
  }

  return `
    <section class="cart-page">
      <h1>Your cart</h1>
      <ul class="cart-list">
        ${lines.map(cartLine).join('')}
      </ul>
      <div class="cart-summary">
        <span>Total</span>
        <span class="cart-total">$${total.toFixed(2)}</span>
      </div>
      <div class="cart-actions">
        <button type="button" id="clear-cart" class="btn-ghost">Clear cart</button>
        <button type="button" id="checkout" class="btn-primary">Checkout</button>
      </div>
    </section>
  `;
}
