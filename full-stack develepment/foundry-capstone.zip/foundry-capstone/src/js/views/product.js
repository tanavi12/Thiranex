import { getProductById } from '../data/products.js';

export function renderProduct(params) {
  const product = getProductById(params.id);

  if (!product) {
    return `
      <section class="not-found">
        <h1>Product not found</h1>
        <p>We couldn't find an item with id "${params.id}".</p>
        <a class="btn-primary" href="#/">Back to shop</a>
      </section>
    `;
  }

  return `
    <section class="product-detail">
      <a class="back-link" href="#/">&larr; Back to shop</a>
      <div class="detail-grid">
        <div class="product-thumb product-thumb--large" style="background:${product.color}22" role="img" aria-label="${product.name}">
          <span class="thumb-mark thumb-mark--large" style="background:${product.color}"></span>
        </div>
        <div class="detail-body">
          <p class="product-category">${product.category}</p>
          <h1 class="detail-name">${product.name}</h1>
          <p class="detail-price">$${product.price.toFixed(2)}</p>
          <p class="detail-description">${product.description}</p>
          <div class="qty-row">
            <label for="qty-input">Qty</label>
            <input id="qty-input" type="number" min="1" value="1" />
          </div>
          <button class="btn-primary" type="button" data-add="${product.id}" data-qty-source="qty-input">
            Add to cart
          </button>
        </div>
      </div>
    </section>
  `;
}
