// Minimal pub/sub store for cart state. Kept framework-free and
// isolated from the router/views so it can be unit-tested or swapped
// for a real state library without touching rendering code.

import { getProductById } from './data/products.js';

const STORAGE_KEY = 'capstone.cart.v1';
const listeners = new Set();

let items = loadCart(); // [{ productId, qty }]

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to read cart from localStorage:', err);
    return [];
  }
}

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (err) {
    console.error('Failed to save cart to localStorage:', err);
  }
}

function notify() {
  listeners.forEach((fn) => fn(getCartDetails()));
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function addToCart(productId, qty = 1) {
  const existing = items.find((i) => i.productId === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    items.push({ productId, qty });
  }
  persist();
  notify();
}

export function updateQty(productId, qty) {
  if (qty <= 0) {
    removeFromCart(productId);
    return;
  }
  const existing = items.find((i) => i.productId === productId);
  if (existing) {
    existing.qty = qty;
    persist();
    notify();
  }
}

export function removeFromCart(productId) {
  items = items.filter((i) => i.productId !== productId);
  persist();
  notify();
}

export function clearCart() {
  items = [];
  persist();
  notify();
}

export function getCartDetails() {
  const lines = items
    .map((i) => {
      const product = getProductById(i.productId);
      if (!product) return null;
      return { ...i, product, subtotal: product.price * i.qty };
    })
    .filter(Boolean);

  const total = lines.reduce((sum, l) => sum + l.subtotal, 0);
  const count = lines.reduce((sum, l) => sum + l.qty, 0);

  return { lines, total, count };
}
