// Lightweight hash-based client-side router.
//
// Hash routing (#/product/p1) is used deliberately over the History
// API: this app ships as static files to Vercel/Netlify/Render, and
// hash routes never hit the server, so no rewrite/redirect rule is
// required on any host for deep links or refreshes to work.

const routes = []; // [{ pattern: RegExp, paramNames: string[], render: fn }]
let outlet = null;
let notFoundRender = null;

export function initRouter(outletEl) {
  outlet = outletEl;
  window.addEventListener('hashchange', handleRouteChange);
  window.addEventListener('load', handleRouteChange);
}

export function registerRoute(path, render) {
  const paramNames = [];
  const patternStr = path
    .split('/')
    .map((segment) => {
      if (segment.startsWith(':')) {
        paramNames.push(segment.slice(1));
        return '([^/]+)';
      }
      return segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');

  routes.push({
    pattern: new RegExp(`^${patternStr}$`),
    paramNames,
    render,
  });
}

export function registerNotFound(render) {
  notFoundRender = render;
}

export function navigate(path) {
  window.location.hash = path;
}

function currentPath() {
  const hash = window.location.hash.replace(/^#/, '');
  return hash || '/';
}

async function handleRouteChange() {
  const path = currentPath();

  for (const route of routes) {
    const match = path.match(route.pattern);
    if (match) {
      const params = {};
      route.paramNames.forEach((name, i) => {
        params[name] = decodeURIComponent(match[i + 1]);
      });
      await renderInto(route.render, params);
      return;
    }
  }

  if (notFoundRender) {
    await renderInto(notFoundRender, {});
  }
}

async function renderInto(render, params) {
  outlet.setAttribute('aria-busy', 'true');
  const html = await render(params);
  outlet.innerHTML = html;
  outlet.removeAttribute('aria-busy');
  outlet.scrollIntoView({ behavior: 'instant', block: 'start' });
  window.dispatchEvent(new CustomEvent('route:rendered', { detail: { params } }));
}
